Shoe's Action RPG Tiles
19/01/24
Tw:@shoehead_art
Itch:https://shoehead.itch.io/
Tumblr:https://www.tumblr.com/shoehedd


Licence:

€5  Personal Version 

    For personal use only, modify and use however you'd like in Jam games and free releases.

€10 Commercial version 

     You can use this for personal and commercial projects. Modify them as much as you want. Can be used in full commercial releases.


-----

Ty for picking this up, I've been working on various Zelda-inspired games for the last few years.
I recently had to leave a very abusive worksplace and strike out on my own (along with a few old collegues) but I'm taking time away from the job soon to care for a newborn son (due next month holy crap!) without maternity pay so working on this pack and putting it up for sale has been my way with dealing with the money based anxiety that's brought on.

Hopefully this helps people put some cool maps together and it kickstarts some cool Zelda-like projects. God knows Nintendo aren't making any atm!

I'm planning on doing some characters and enemies soon, depending on my free time!

Also as for my own projects, while they use graphics included in this pack, don't worry. I'm not going to give up on them! 

-Shoe